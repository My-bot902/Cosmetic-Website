---
name: Lush Minimalist Luxury
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1b1b1c'
  on-surface-variant: '#46483c'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0ef'
  outline: '#76786b'
  outline-variant: '#c6c8b8'
  surface-tint: '#56642b'
  primary: '#56642b'
  on-primary: '#ffffff'
  primary-container: '#8a9a5b'
  on-primary-container: '#253000'
  inverse-primary: '#bdce89'
  secondary: '#8c4b55'
  on-secondary: '#ffffff'
  secondary-container: '#feaab6'
  on-secondary-container: '#7a3c46'
  tertiary: '#5e604d'
  on-tertiary: '#ffffff'
  tertiary-container: '#94957f'
  on-tertiary-container: '#2c2e1d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d9eaa3'
  primary-fixed-dim: '#bdce89'
  on-primary-fixed: '#161f00'
  on-primary-fixed-variant: '#3e4c16'
  secondary-fixed: '#ffd9dd'
  secondary-fixed-dim: '#ffb2bc'
  on-secondary-fixed: '#3a0915'
  on-secondary-fixed-variant: '#70343e'
  tertiary-fixed: '#e4e4cc'
  tertiary-fixed-dim: '#c8c8b0'
  on-tertiary-fixed: '#1b1d0e'
  on-tertiary-fixed-variant: '#474836'
  background: '#fcf9f8'
  on-background: '#1b1b1c'
  surface-variant: '#e5e2e1'
  sage-bg: '#F1F3EB'
  rose-gold-muted: '#C29B8F'
  cream-accent: '#FAF9F6'
  charcoal-text: '#1F1F1F'
typography:
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  baseline: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
---

## Brand & Style
The design system embodies "Luxury Skincare Made Affordable," bridging the gap between high-end editorial aesthetics and accessible retail. The brand personality is serene, botanical, and sophisticated, rooted in a Pakistani heritage of natural beauty rituals reimagined for the modern woman. 

The visual style is **Minimalist with High-Contrast editorial touches**. It prioritizes generous whitespace to create a "breathable" user experience, using premium materials like muted rose gold and sage green to evoke a sense of organic luxury. The interface should feel like a high-end apothecary—structured, clean, and intentionally quiet, allowing product photography to remain the focal point.

## Colors
The palette is inspired by natural flora and earth tones. 

- **Primary (Sage Green):** Used primarily for backgrounds (`#F1F3EB`) and subtle UI accents to reinforce the botanical theme.
- **Secondary (Muted Rose Gold):** Reserved for primary call-to-action buttons and key interactive highlights, providing a warm, metallic contrast to the cool greens.
- **Tertiary (Cream/Beige):** Used for card backgrounds and container surfaces to create soft depth against the sage backdrop.
- **Neutral (Charcoal):** Provides high-contrast legibility for all typography and iconography, ensuring the brand feels grounded and professional.

## Typography
The typography strategy utilizes a "High-Low" pairing. **Playfair Display** brings an editorial, high-fashion authority to headings, while **Inter** provides a utilitarian, clean foundation for transactional data and long-form reading.

Key principles:
- Use `headline-xl` for hero sections with tight letter-spacing for a modern look.
- Use `label-caps` for small metadata, categories, or overlines to add a structured, organized feel.
- Maintain ample line-height in body text to preserve the minimalist, airy aesthetic.

## Layout & Spacing
The layout follows a **Fixed Grid** system for desktop to maintain an editorial, magazine-like feel, centering content within a 1280px container. On mobile, the system transitions to a fluid 4-column layout.

Spacing is governed by an 8px base unit. To achieve the "Lush" aesthetic, use larger-than-standard vertical padding between sections (typically 80px to 120px on desktop) to force a slower, more deliberate scrolling experience. High-contrast negative space is essential; do not crowd product cards or text blocks.

## Elevation & Depth
Depth is conveyed through **Tonal Layers** and **Ambient Shadows** rather than heavy borders.

- **Surfaces:** Use the `cream-accent` for cards sitting on top of the `sage-bg`.
- **Shadows:** Use extremely soft, high-diffusion shadows (e.g., `blur: 40px, opacity: 4%`) with a slight tint of the secondary rose gold or sage green to avoid "dirty" gray shadows.
- **Glassmorphism:** Apply a light backdrop blur (8px) on navigation bars and modals to maintain a sense of environmental continuity.

## Shapes
This design system uses **Soft (0.25rem)** roundedness. This subtle curvature maintains a modern, architectural precision while feeling more approachable than sharp 90-degree corners. 

Buttons and input fields should utilize the base `rounded` (4px) setting, while larger containers like product images or promotional banners may scale up to `rounded-lg` (8px) to soften the overall visual impact.

## Components
- **Buttons:** The primary button is `rose-gold-muted` with `charcoal-text`. It uses a subtle lift on hover. Secondary buttons are outlined in charcoal with no fill.
- **Inputs:** Fields use a `cream-accent` background with a bottom-border-only focus state in `rose-gold-muted` to mimic high-end stationery.
- **Cards:** Product cards should be borderless, using soft ambient shadows and the `cream-accent` surface. Images should have a consistent aspect ratio (usually 4:5 for skincare).
- **Chips/Badges:** Use `sage-bg` with `charcoal-text` for categories like "Organic" or "New Arrival," utilizing the `label-caps` typography style.
- **Lists:** Use generous vertical padding and thin, low-opacity charcoal dividers (10% opacity) to maintain a clean, organized hierarchy.